%% ``The contents of this file are subject to the Erlang Public License,
%% Version 1.1, (the "License"); you may not use this file except in
%% compliance with the License. You should have received a copy of the
%% Erlang Public License along with this software. If not, it can be
%% retrieved via the world wide web at http://www.erlang.org/.
%% 
%% Software distributed under the License is distributed on an "AS IS"
%% basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
%% the License for the specific language governing rights and limitations
%% under the License.
%% 
%% The Initial Developer of the Original Code is Ericsson Utvecklings AB.
%% Portions created by Ericsson are Copyright 1999, Ericsson Utvecklings
%% AB. All Rights Reserved.''
%% 
%%     $Id$
%%
%%%-------------------------------------------------------------------
%%% File    : ts.erl
%%% Purpose : Frontend for running tests.
%%%-------------------------------------------------------------------

-module(ts).

-export([run/0, run/1, run/2, run/3, run/4,
	 clean/0, clean/1,
	 save/0, save/1, update/0, tests/0, tests/1,
	 install/0, install/1, install/2, index/0,
	 estone/0, estone/1,
	 help/0]).
-export([i/0, l/1, r/0, r/1, r/2]).

%%%----------------------------------------------------------------------
%%% This module, ts, is the interface to all of the functionality of
%%% the TS framework.  The picture below shows the relationship of
%%% the modules:
%%%
%%%       +-- ts_install --+------  ts_autoconf_win32
%%%       |                |
%%%       |                +------  ts_autoconf_vxworks
%%%       |
%%%       |                +------  ts_erl_config
%%%       |                |				     ts_lib
%%%       |                +------  ts_make
%%%       |                |
%%% ts ---+-- ts_run  -----+
%%%       |                |	    			     ts_filelib
%%%       |                +------  ts_make_erl
%%%       |                |
%%%       |                +------  ts_reports (indirectly)
%%%       |
%%%       |
%%%       +-- ts_save   ----------  ts_reports
%%%
%%% The modules ts_lib and ts_filelib contains utilities used by
%%% the other modules.
%%%
%%% Module		 Description
%%% ------		 -----------
%%% ts			 Frontend to the test server framework.  Contains all
%%%			 interface functions.
%%% ts_install		 Installs the test suite.  On Unix, `autoconf' is
%%%			 is used; on Windows, ts_autoconf_win32 is used,
%%%                      on VxWorks, ts_autoconf_vxworks is used.
%%%			 The result is written to the file `variables'.
%%% ts_run		 Supervises running of the tests.
%%% ts_save		 Saves log files in the central log directory
%%%			 and updates index pages.  The standard erl_tar
%%%			 module is used to copy the log files.
%%% ts_autconf_win32	 An `autoconf' for Windows.
%%% ts_autconf_cross_env `autoconf' for other platforms (cross environment)
%%% ts_erl_config	 Finds out information about the Erlang system,
%%%			 for instance the location of erl_interface.
%%%			 This works for an installed OTP/EDE, or an Erlang
%%%			 system running from Clearcase.
%%% ts_make		 Interface to run the `make' program on Unix
%%%			 and other platforms.
%%% ts_make_erl		 A corrected version of the standar Erlang module
%%%			 make (used for rebuilding test suites).
%%% ts_reports		 Generates index pages in HTML, providing a summary
%%%			 of the tests run.
%%% ts_lib		 Miscellanous utility functions, each used by several
%%%			 other modules.
%%%----------------------------------------------------------------------

-include_lib("kernel/include/file.hrl").
-include("ts.hrl").

-define(
   install_help,
   [
    "  ts:install()      - Install TS for local target with no Options.\n"
    "  ts:install([Options])\n",
    "                    - Install TS for local target with Options\n"
    "  ts:install({Architecture, Target_name})\n",
    "                    - Install TS for a remote target architecture.\n",
    "                      and target network name (e.g. {vxworks_cpu32, sauron}).\n",
    "  ts:install({Architecture, Target_name}, [Options])\n",
    "                    - Install TS as above, and with Options.\n",
    "\n",
    "Installation options supported:\n",
    "  {longnames, true} - Use fully qualified hostnames\n",
    "  {hosts, [HostList]}\n"
    "                    - Use theese hosts for distributed testing.\n"
    "  {verbose, Level}  - Sets verbosity level for TS output (0,1,2), 0 is\n"
    "                      quiet(default).\n"
    "  {slavetargets, SlaveTarges}\n"
    "                    - Available hosts for starting slave nodes for\n"
    "                      platforms which cannot have more than one erlang\n"
    "                      node per host.\n"
    "  {crossroot, TargetErlRoot}\n"
    "                    - Erlang root directory on target host\n"
    "                      Mandatory for remote targets\n"
    "  {master, {MasterHost, MasterCookie}}\n"
    "                    - Master host and cookie for targets which are\n"
    "                      started as slave nodes (i.e. OSE/Delta targets\n"
    "                      erl_boot_server must be started on master before\n"
    "                      test is run.\n"
    "                      Optional, default is controller host and then\n"
    "                      erl_boot_server is started autmatically\n"
   ]).

help() ->
    case filelib:is_file(?variables) of
	false -> help(uninstalled);
	true  -> help(installed)
    end.

help(uninstalled) ->
    H = ["TS is not installed yet.  To install use:\n\n"],
    show_help([H,?install_help]);
help(installed) ->
    H = ["Run functions:\n",
	 "  ts:run()          - Run all available tests.\n",
	 "  ts:run(Spec)      - Run all tests in given test spec file.\n",
	 "                      The spec file is actually ../*_test/Spec.spec\n",
	 "  ts:run([Specs])   - Run all tests in all given test spec files.\n",
	 "  ts:run(Spec, Mod) - Run a single test suite.\n",
	 "  ts:run(Spec, Mod, Case)\n",
	 "                    - Run a single test case.\n",
	 "  All above run functions can have the additional Options argument\n",
	 "  which is a list of options.\n",
	 "\n",
	 "Run options supported:\n",
	 "  batch             - Do not start a new xterm\n",
	 "  {verbose, Level}  - Same as the verbosity option for install\n",
	 "  verbose           - Same as {verbose, 1}\n",
	 "  {vars, Vars}      - Variables in addition to the 'variables' file\n",
	 "                      Can be any of the install options\n",
	 "  {trace, TraceSpec}- Start call trace on target and slave nodes\n",
	 "                      TraceSpec is the name of a file containing\n",
	 "                      trace specifications or a list of trace\n",
	 "                      specification elements.\n",
	 "\n",
	 "Supported trace information elements\n",
	 "  {tp | tpl, Mod, [] | match_spec()}\n",
	 "  {tp | tpl, Mod, Func, [] | match_spec()}\n",
	 "  {tp | tpl, Mod, Func, Arity, [] | match_spec()}\n",
	 "  {ctp | ctpl, Mod}\n",
	 "  {ctp | ctpl, Mod, Func}\n",
	 "  {ctp | ctpl, Mod, Func, Arity}\n",
	 "\n",
	 "Support functions\n",
	 "  ts:tests()        - Shows all available families of tests.\n",
	 "  ts:tests(Spec)    - Shows all available test modules in Spec,\n",
	 "                      i.e. ../Spec_test/*_SUITE.erl\n",
	 "  ts:index()        - Updates local index page.\n",
	 "  ts:clean()        - Cleans up all but the last tests run.\n",
	 "  ts:clean(all)     - Cleans up all test runs found.\n",
	 "  ts:save()         - Save log files at central site.\n",
	 "  ts:save(release)  - Saves log files in a dedicated directory\n",
	 "                      named after the current OTP release.\n",
	 "  ts:save(Path)     - Save log files at central site, Path is\n",
	 "                      appended to 'central_log_dir'.\n",
	 "  ts:update()       - Unpack any tar files at central log file\n",
	 "                      location and update index pages.\n",
	 "  ts:estone()       - Run estone_SUITE in kernel application with\n"
	 "                      no run options\n",
	 "  ts:estone(Opts)   - Run estone_SUITE in kernel application with\n"
	 "                      the given run options\n",
	 " \n"
	 "Installation (already done):\n"
	],
    show_help([H,?install_help]).

show_help(H) ->
    io:put_chars(lists:flatten(H)).


%% Installs tests.
install() ->
    ts_install:install(install_local,[]).
install({Architecture, Target_name})  ->
    ts_install:install({ts_lib:maybe_atom_to_list(Architecture), 
			ts_lib:maybe_atom_to_list(Target_name)}, []);
install(Options) when list(Options) ->
    ts_install:install(install_local,Options).
install({Architecture, Target_name}, Options) when list(Options)->
    ts_install:install({ts_lib:maybe_atom_to_list(Architecture), 
			ts_lib:maybe_atom_to_list(Target_name)}, Options).



%% Saves all log files in the central location. (Release)

save(release) ->
    check_and_run({ts_save,save});
save(Name) ->
    check_and_run(fun(Vars) -> ts_save:save(Vars, Name), ok end).

%% Saves all log files in a time-stamped directory. (e.g. R2D/progress/10-Oct-97/)
save() ->
    check_and_run({ts_save,save_progress}).

%% Updates log files in the central location.

update() ->
    check_and_run({ts_save,update}).

%% Updates the local index page.

index() ->
    check_and_run(fun(_Vars) -> ts_reports:make_index(), ok end).

%%
%% clean(all)
%% Deletes all logfiles.
%%
clean(all) ->
    delete_files(filelib:wildcard("*" ++ ?logdir_ext)).

%% clean/0
%%
%% Cleans up run logfiles, all but the last run.
clean() ->
    clean1(filelib:wildcard("*" ++ ?logdir_ext)).

clean1([Dir|Dirs]) ->
    List0 = filelib:wildcard(filename:join(Dir, "run.*")),
    case lists:reverse(lists:sort(List0)) of
	[] -> ok;
	[_Last|Rest] -> delete_files(Rest)
    end,
    clean1(Dirs);
clean1([]) -> ok.

%% run/0
%%  Runs all specs found by ts:tests(), if any, or returns
%%  {error, no_tests_available}. (batch)
run() ->
    case ts:tests() of
	[] ->
	    {error, no_tests_available};
	_ ->
	    check_and_run(fun(Vars) -> run_all(Vars) end)
    end.
run_all(_Vars) ->
    run_some(tests(), [batch]).

run_all_interactive(_Vars) ->
    exit(self(), {error, cannot_run_all_tests_in_interactive_mode}),
    ok.

run_some([], _Opts) ->
    ok;
run_some([Spec|Specs], Opts) ->
    case run(Spec, Opts) of
	ok -> ok;
	Error -> io:format("~p: ~p~n",[Spec,Error])
    end,
    run_some(Specs, Opts).

%% run/1
%%  Apply any test run from the command line.
%%  Usage: erl -s ts run1 '{Mod,Func,ArgList}'
run([Atom]) when atom(Atom) ->
    Str = atom_to_list(Atom),
    Args = to_erlang_term(Str),
    apply(ts,run,Args);

run(List) when list(List) ->
    run_some(List, [batch]);

%% Runs one test spec (interactive).
run(Testspec) when atom(Testspec) ->
    Options=check_test_get_opts(Testspec, []),
    File = atom_to_list(Testspec),
    run_test(File, ["SPEC current.spec NAME ",File], Options);
%% Runs all test specs with Config.
%%! THIS IS NEVER RUN - other clause is selected first!!!
run(Config) when list(Config) ->
    Runner = configmember(batch,
			  {fun(Vars) -> run_all(Vars) end,
			   fun(Vars) -> run_all_interactive(Vars) end},
			  Config),
    case ts:tests() of
	[] ->
	    {error, no_tests_available};
	_ ->
	    check_and_run(Runner)
    end.

run(List, Opts) when list(List), list(Opts) ->
    run_some(List, Opts);

%% run/2
%% Runs one test spec with Options
run(Testspec, Config) when atom(Testspec), list(Config) ->
    Options=check_test_get_opts(Testspec, Config),
    File=atom_to_list(Testspec),
    run_test(File, ["SPEC current.spec NAME ", File], Options);
%% Runs one module in a spec (interactive)
run(Testspec, Mod) when atom(Testspec), atom(Mod) ->
    run_test({atom_to_list(Testspec), Mod}, 
	     ["SPEC current.spec NAME ", atom_to_list(Mod)], 
	     [interactive]).

%% run/3
%% Run one module in a spec with Config
run(Testspec,Mod,Config) when atom(Testspec), atom(Mod), list(Config) ->
    Options=check_test_get_opts(Testspec, Config),
    run_test({atom_to_list(Testspec), Mod},
	     ["SPEC current.spec NAME ", atom_to_list(Mod)], 
	     Options);

%% Runs one testcase in a module.
run(Testspec, Mod, Case) when atom(Testspec), atom(Mod), atom(Case) ->
    Options=check_test_get_opts(Testspec, []),
    Args = ["CASE ",atom_to_list(Mod)," ",atom_to_list(Case)],
    run_test(atom_to_list(Testspec), Args, Options).

%% run/4
%% Run one testcase in a module with Options.
run(Testspec, Mod, Case, Config) when atom(Testspec), atom(Mod), atom(Case), list(Config) ->
    Options=check_test_get_opts(Testspec, Config),
    Args = ["CASE ",atom_to_list(Mod), " ",atom_to_list(Case)],
    run_test(atom_to_list(Testspec), Args, Options).

%% Check testspec to be valid and get possible Options
%% from the config.
check_test_get_opts(Testspec, Config) ->
    validate_test(Testspec),
    Mode = configmember(batch, {batch, interactive}, Config),
    Vars = configvars(Config),
    Trace = configtrace(Config),
    KeepTopcase = configmember(keep_topcase, {[keep_topcase],[]}, Config),
    lists:flatten([Vars,Mode,Trace]) ++ KeepTopcase.
    
to_erlang_term(String) ->
    {ok, Tokens, _} = erl_scan:string(lists:append([String, ". "])),
    {ok, Term} = erl_parse:parse_term(Tokens),
    Term.

%% Validate that a Testspec really is a testspec,
%% and exit if not.
validate_test(Testspec) ->
    case lists:member(Testspec, tests()) of
	true ->
	    ok;
	false ->
	    io:format("This testspec does not seem to be "
		      "available.~n Please try ts:tests() "
		      "to see available tests.~n"),
	    exit(self(), {error, test_not_available})
    end.
    
configvars(Config) ->
    case lists:keysearch(vars, 1, Config) of
	{value, {vars, List}} ->
	    List0 = special_vars(Config),
	    {vars, [List0|List]};
	_ ->
	    {vars, special_vars(Config)}
    end.

%% Allow some shortcuts in the Options...
special_vars(Config) ->
    Verbose=
	case lists:member(verbose, Config) of
	    true ->
		{verbose, 1};
	    false ->
		case lists:keysearch(verbose, 1, Config) of
		    {value, {verbose, Lvl}} ->
			{verbose, Lvl};
		    _ ->
			{verbose, 0}
		end
	end,
    case lists:keysearch(diskless, 1, Config) of
	{value,{diskless, true}} ->
	    [Verbose,{diskless, true}];
	_ ->
	    [Verbose]
    end.

configtrace(Config) ->
    case lists:keysearch(trace,1,Config) of
	{value,Value} -> [Value];
	false -> []
    end.

configmember(Member, {True, False}, Config) ->
    case lists:member(Member, Config) of
	true ->
	    True;
	false ->
	    False
    end.


%% Returns a list of available test suites.

tests() ->
    {ok, Cwd} = file:get_cwd(),
    ts_lib:specs(Cwd).

tests(Spec) ->
    {ok, Cwd} = file:get_cwd(),
    ts_lib:suites(Cwd, atom_to_list(Spec)).


%% 
%% estone/0, estone/1
%% Opts = same as Opts or Config for the run(...) function, 
%% e.g. [batch]
%% 
estone() -> run(emulator,estone_SUITE).
estone(Opts) when list(Opts) -> run(emulator,estone_SUITE,Opts).


%%% Implementation.

check_and_run(Fun) ->
    case file:consult(?variables) of
	{ok, Vars} ->
	    check_and_run(Fun, Vars);
	{error, Error} when atom(Error) ->
	    {error, not_installed};
	{error, Reason} ->
	    {error, {bad_installation, file:format_error(Reason)}}
    end.

check_and_run(Fun, Vars) ->
    Platform = ts_install:platform_id(Vars),
    case lists:keysearch(platform_id, 1, Vars) of
	{value, {_, Platform}} ->
	    case catch apply(Fun, [Vars]) of
		{'EXIT', Reason} ->
		    exit(Reason);
		Other ->
		    Other
	    end;
	{value, {_, OriginalPlatform}} ->
	    io:format("These test suites were installed for '~s'.\n",
		      [OriginalPlatform]),
	    io:format("But the current platform is '~s'.\nPlease "
		      "install for this platform before running "
		      "any tests.", [Platform]),
	    {error, inconsistent_platforms};
	false ->
	    {error, {bad_installation, no_platform}}
    end.

run_test(File, Args, Options) ->
    check_and_run(fun(Vars) -> run_test(File, Args, Options, Vars) end).

run_test(File, Args, Options, Vars) ->
    ts_run:run(File, Args, Options, Vars).


delete_files([]) -> ok;
delete_files([Item|Rest]) ->
    case file:delete(Item) of
	ok ->
	    delete_files(Rest);
	{error,eperm} ->
	    file:change_mode(Item, 8#777),
	    delete_files(filelib:wildcard(filename:join(Item, "*"))),
	    file:del_dir(Item),
	    ok;
	{error,eacces} ->
	    %% We'll see about that!
	    file:change_mode(Item, 8#777),
	    case file:delete(Item) of
		ok -> ok;
		{error,_} ->
		    erlang:yield(),
		    file:change_mode(Item, 8#777),
		    file:delete(Item),
		    ok
	    end;
	{error,_} -> ok
    end,
    delete_files(Rest).


%% This module provides some convenient shortcuts to running
%% the test server from within a started Erlang shell.
%% (This are here for backwards compatibility.)
%%
%% r()
%% r(Mod)
%% r(Mod, Case)
%%	Each of these functions starts the test server if it
%%	isn't already running, then runs the test case(s) selected
%%	by the aguments.  The module Mod will be reloaded before
%%	running the test cases.
%%
%% i()
%%	Shows information about the jobs being run, by dumping
%%	the process information for the test_server.
%%
%% l(Mod)
%%	This function reloads a module just like c:l/1, but works
%%	even for a module in one of the sticky library directories
%%	(for instance, lists can be reloaded).

%% Runs all tests cases in the current directory.

r() ->
    ensure_ts_started(),
    test_server_ctrl:add_dir("current_dir", ".").

%% Checks if argument is a spec file or a module 
%% (spec file must be named "*.spec" or "*.spec.OsType")
%% If module, reloads module and runs all test cases in it.
%% If spec, runs all test cases in it.

r(SpecOrMod) ->
    ensure_ts_started(),
    case filename:extension(SpecOrMod) of
	[] ->
	    l(SpecOrMod),
	    test_server_ctrl:add_module(SpecOrMod);
	".spec" -> 
	    test_server_ctrl:add_spec(SpecOrMod);
	_ ->
	    Spec2 = filename:rootname(SpecOrMod),
	    case filename:extension(Spec2) of
		".spec" ->
		    %% *.spec.Type
		    test_server_ctrl:add_spec(SpecOrMod);
		_ ->
		    {error, unknown_filetype}
	    end		    
    end.

%% Reloads the given module and runs the given test case in it.

r(Mod, Case) ->
    ensure_ts_started(),
    l(Mod),
    test_server_ctrl:add_case(Mod, Case).

%% Shows information about the jobs being run.

i() ->
    ensure_ts_started(),
    hformat("Job", "Current", "Total", "Success", "Failed", "Skipped"),
    i(test_server_ctrl:jobs()).
 
i([{Name, Pid}|Rest]) when pid(Pid) ->
    {dictionary, PI} = process_info(Pid, dictionary),
    {value, {_, CaseNum}} = lists:keysearch(test_server_case_num, 1, PI),
    {value, {_, Cases}} = lists:keysearch(test_server_cases, 1, PI),
    {value, {_, Failed}} = lists:keysearch(test_server_failed, 1, PI),
    {value, {_, Skipped}} = lists:keysearch(test_server_skipped, 1, PI),
    {value, {_, Ok}} = lists:keysearch(test_server_ok, 1, PI),
    nformat(Name, CaseNum, Cases, Ok, Failed, Skipped),
    i(Rest);
i([]) ->
    ok.
 
hformat(A1, A2, A3, A4, A5, A6) ->
    io:format("~-20s ~8s ~8s ~8s ~8s ~8s~n", [A1,A2,A3,A4,A5,A6]).
 
nformat(A1, A2, A3, A4, A5, A6) ->
    io:format("~-20s ~8w ~8w ~8w ~8w ~8w~n", [A1,A2,A3,A4,A5,A6]).

%% Force load of a module even if it is in a sticky directory.

l(Mod) ->
    case do_load(Mod) of
	{error, sticky_directory} ->
	    Dir = filename:dirname(code:which(Mod)),
	    code:unstick_dir(Dir),
	    do_load(Mod),
	    code:stick_dir(Dir);
	X ->
	    X
    end.


ensure_ts_started() ->
    case whereis(test_server_ctrl) of
	undefined ->
	    test_server_ctrl:start();
	Pid when pid(Pid) ->
	    Pid
    end.


do_load(Mod) ->
    code:purge(Mod),
    code:load_file(Mod).
