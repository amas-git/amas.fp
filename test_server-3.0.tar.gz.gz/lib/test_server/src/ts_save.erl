%% ``The contents of this file are subject to the Erlang Public License,
%% Version 1.1, (the "License"); you may not use this file except in
%% compliance with the License. You should have received a copy of the
%% Erlang Public License along with this software. If not, it can be
%% retrieved via the world wide web at http://www.erlang.org/.
%% 
%% Software distributed under the License is distributed on an "AS IS"
%% basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
%% the License for the specific language governing rights and limitations
%% under the License.
%% 
%% The Initial Developer of the Original Code is Ericsson Utvecklings AB.
%% Portions created by Ericsson are Copyright 1999, Ericsson Utvecklings
%% AB. All Rights Reserved.''
%% 
%%     $Id$
%%
%%% Purpose : Saves log files in a central location.

-module(ts_save).

-export([save/2, save_progress/1]).

-include_lib("kernel/include/file.hrl").
-import(ts_lib, [error/1]).
-include("ts.hrl").


%% Saves all log files.

save(Vars, Name) ->
    case save_get_logdir(Vars) of
	error ->
	    save_error(),
	    {error, no_central_log_dir};
	SaveDir0 ->
	    SaveDir = filename:join([SaveDir0, Name]),
	    save_dir(SaveDir, Vars)
    end.

save_progress(Vars) ->
    case save_get_logdir(Vars) of
	error ->
	    save_error();
	SaveDir0 -> % /usr/local/otp
	    VsnName = erlang:system_info(version),
	    SaveDir1 = filename:join([SaveDir0, "test",
				      "progress" ++ "_"
				      ++ ts_lib:var(erl_release, Vars)]),
	    SaveDir = filename:join(SaveDir1, VsnName),
	    save_dir(SaveDir, Vars),
	    ts_reports:make_progress_index(SaveDir1, Vars)
    end.
	    
save_get_logdir(Vars) ->
    SaveDir0 = ts_lib:var(central_log_dir, Vars),
    Dir=
	case SaveDir0 of
	    "@central_log_dir@" ->
		error;
	    [] ->
		error;
	    _ ->
		SaveDir0
	end,
    case Dir of
	error ->
	    case os:getenv("central_log_dir") of
		false ->
		    error;
		Direct ->
		    Direct
	    end;
	Other ->
	    Other
    end.
	    
    
save_dir(TestDir, Vars) ->
    PlatformName = ts_lib:var(platform_filename, Vars),
    Filename = PlatformName ++ ".tar",
    Directory = filename:join([TestDir, PlatformName]),
    TarName = filename:join([Directory, Filename]),
    make_tar(TarName),
    update(Directory, Vars).

save_error() ->
    io:format("Sorry, cannot save the test results because `central_log_dir' "
	      "is not set.~n"
	      "To set it, use either ts:install(`option_spec_will_be_added') "
	      "or set the~n"
	      "environment variable `central_log_dir'.~n",[]),
    {error, no_central_log_dir}.

%%% Updating log files in central location.

update(TestDir, Vars) ->
    extract_tars(TestDir),
    %% cd .. (TestDir/../)
    TheDir=filename:dirname(TestDir),
    ts_reports:make_master_index(TheDir, Vars).

    
extract_tars(Dir) ->
    lists:foreach(fun extract_tar/1,
		  filelib:wildcard(filename:join(Dir, "*.tar"))).

extract_tar(TarName) ->
    io:format("Extracting ~s... ", [TarName]),
    TestDir = filename:dirname(TarName),
    lists:foreach(fun(Name) -> ts_lib:force_delete(Name) end,
		  to_delete(TarName, TestDir)),
    case erl_tar:extract(TarName, [{cwd, TestDir}, compressed]) of
	ok ->
	    file:delete(TarName),
	    io:put_chars("done\n");
	{error, Reason} ->
	    io:format("FAILED: ~p\n", [Reason])
	    %io:put_chars("FAILED\n")
    end.

to_delete(TarName, Dir) ->
    {ok, Contents} = erl_tar:table(TarName, [compressed]),
    [filename:join(Dir, X) || X <- Contents, not_run(X)].

not_run(Name) ->
    case regexp:match(Name, "run\\.[0-9]") of
	{match, _, _} -> false;
	_ -> true
    end.

%%% Making tar files.

make_tar(TarName) ->
    io:format("Saving log files in ~s~n", [TarName]),
    file:delete(TarName),
    case create_tar(TarName,4) of
	{ok, Tar} ->
	    add_tar(Tar, "variables"),
	    LogDirs = ts_lib:interesting_logs("."),
	    lists:foreach(fun(Dir) -> add_each_dir(Tar, Dir) end,
			  LogDirs),
	    ok = erl_tar:close(Tar),
	    ok;
	{error, Reason} ->
	    error({create_tar_file, Reason})
    end.

create_tar(_TarName,0) ->
    {error,cannot_create_tar};
create_tar(TarName,N) ->
    case erl_tar:open(TarName, [write,compressed]) of
	{ok, Tar} ->
	    {ok, Tar};
	{error, enoent} ->			% Old erl_tar error code
	    make_dirs(TarName),
	    create_tar(TarName,N-1);
	{error, {_,enoent}} ->			% New erl_tar error code
	    make_dirs(TarName),
	    create_tar(TarName,N-1)
    end.

%% Makes all directories leading up to the file.

make_dirs(Name) ->
    make_dirs1(filename:split(Name)).

make_dirs1([Dir, Next|Rest]) ->
    case file:read_file_info(Dir) of
	{ok, #file_info{type=directory}} ->
	    make_dirs1([filename:join(Dir, Next)|Rest]);
	{ok, #file_info{type=_Other}} ->
	    {error, enotdir};
	{error, _} ->
	    case file:make_dir(Dir) of
		ok -> make_dirs1([filename:join(Dir, Next)|Rest]);
		{error, Reason} -> error(Reason)
	    end
    end;
make_dirs1([_File]) -> ok;
make_dirs1([]) ->
    %% There must be something wrong here.  The list was not supposed
    %% to be empty.
    error(enoent).

add_tar(Tar, File) ->
%    io:format("~p, ~p~n", [Tar, File]),
    ok = erl_tar:add(Tar, File, File, []).

add_each_dir(Tar, Dir) ->
    LastTest = ts_lib:last_test(Dir),
    FilesToAdd = filelib:wildcard(filename:join(LastTest,
						  "*.{log,html,summary}")),
    lists:foreach(fun(File) -> add_tar(Tar, File) end, FilesToAdd).
