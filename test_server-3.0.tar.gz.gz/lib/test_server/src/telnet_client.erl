%% ``The contents of this file are subject to the Erlang Public License,
%% Version 1.1, (the "License"); you may not use this file except in
%% compliance with the License. You should have received a copy of the
%% Erlang Public License along with this software. If not, it can be
%% retrieved via the world wide web at http://www.erlang.org/.
%% 
%% Software distributed under the License is distributed on an "AS IS"
%% basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
%% the License for the specific language governing rights and limitations
%% under the License.
%% 
%% The Initial Developer of the Original Code is Ericsson Utvecklings AB.
%% Portions created by Ericsson are Copyright 1999, Ericsson Utvecklings
%% AB. All Rights Reserved.''
%% 
%%     $Id$
%%
-module(telnet_client).
-author('peppe@erix.ericsson.se').

-export([open/1, open/2, close/1, send_data/2, send_cmd/2, send_cmd/3]).
-export([init/2, printable/1]).    

-define(DBG, false).

-define(TELNET_PORT, 23).

-define(SE,	240).
-define(NOP,	241).
-define(DM,	242).
-define(BRK,	243).
-define(IP,	244).
-define(AO,	245).
-define(AYT,	246).
-define(EC,	247).
-define(EL,	248).
-define(GA,	249).
-define(SB,	250).
-define(WILL,	251).
-define(WONT,	252).
-define(DO,	253).
-define(DONT,	254).
-define(IAC,	255).
-define(BINARY,            0).
-define(ECHO,	           1).
-define(SUPPRESS_GO_AHEAD, 3).
-define(TERMINAL_TYPE,     24).  
-define(WINDOW_SIZE,       31).

open(Server) ->
    open(Server, ?TELNET_PORT).

open(Server, Port) ->
    Pid = spawn(?MODULE, init, [Server, Port]),
    timer:sleep(500),
    Pid.

close(Pid) ->
    timer:sleep(500),
    Pid ! close.

send_data(Pid, Data) ->
    Pid ! {send_data,Data++"\r\n"},
    timer:sleep(500),
    ok.

send_cmd(Pid, Cmd, Opt) ->
    send_cmd(Pid, [Cmd,Opt]).

send_cmd(Pid, CmdList) ->
    Pid ! {send_cmd,CmdList},
    timer:sleep(500),
    ok.

init(Server, Port) ->
    {ok,Sock} = gen_tcp:connect(Server, Port, [list,{packet,0}], 30000),
    dbg(["Connected to: ", Server]),
    io:nl(),
    send([?IAC,?DO,?SUPPRESS_GO_AHEAD,
	  ?IAC,?DO,?BINARY,
	  ?IAC,?DONT,?ECHO,
	  ?IAC,?DONT,?TERMINAL_TYPE,
	  ?IAC,?DONT,?WINDOW_SIZE], Sock),	      
    InitMsg = get_msg(),
    respond(init, InitMsg, Sock),
    loop(normal, Sock, Server, [], 10000),
    gen_tcp:close(Sock).

loop(State, Sock, Server, Acc, TO) ->
    receive
	{send_data,Data} ->
	    send(Data, Sock),
	    loop(State, Sock, Server, [], 10000);
	{send_cmd,CmdList} ->
	    send([?IAC | CmdList], Sock),
	    loop(State, Sock, Server, [], 10000);
	{tcp,_,Msg} ->	    
	    loop(State, Sock, Server, Acc++Msg, 2000);
	close ->
	    dbg(["Closing connection to ", Server]),
	    ok
    after TO ->
	    State1 = respond(State, Acc, Sock),
	    loop(State1, Sock, Server, [], 10000)
    end.    

send(Data, Sock) ->
    dbg(["Sending: ", Data]),
    gen_tcp:send(Sock, Data),
    ok.

get_msg() ->
    get_msg1([]).

get_msg1(Acc) ->
    receive
	{tcp,_,Msg} ->
	    get_msg1(Acc ++ Msg)
    after 2000 ->
	    Acc
    end.
	
respond(State, [?IAC | Cs], Sock) ->		% cmd received
    {Cmd,Cs1} = get_cmd(Cs),
    dbg(["CMD: ", Cmd]),
    State1 = respond_cmd(State, Cmd, Sock),
    respond(State1, Cs1, Sock); 

respond(State, [], _Sock) ->
    State;

respond(State, Cs, Sock) ->			% data received
    {Data,Cs1} = get_data(Cs),			
    %% dbg(["DATA: ", Data]),
    io:format("~s~n", [Data]),
    State1 = respond_data(State, Data, Sock),
    respond(State1, Cs1, Sock).

respond_cmd(State, [?WILL,?ECHO], Sock) ->
    R = [?IAC,?DO,?ECHO],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [?WILL,?SUPPRESS_GO_AHEAD], Sock) ->
    R = [?IAC,?DO,?SUPPRESS_GO_AHEAD],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [?WILL,?BINARY], Sock) ->
    R = [?IAC,?DO,?BINARY],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [?DO,?TERMINAL_TYPE], Sock) ->
    R = [?IAC,?DONT,?TERMINAL_TYPE],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [?WILL,Opt], Sock) ->
    R = [?IAC,?WONT,Opt],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [?DO | Opt], Sock) ->
    R = [?IAC,?DONT | Opt],
    dbg(["Response: ", R]),
    gen_tcp:send(Sock, R),
    State;

respond_cmd(State, [Cmd | Opt], _Sock) when Cmd >= 240, Cmd =< 255 ->
    dbg(["Received cmd: ", [Cmd | Opt], "\nIgnored."]),
    State;

respond_cmd(State, [], _Sock) ->
    State.

%% match on Data here
respond_data(State, _Data, _Sock) ->
    State.

get_cmd([Cmd | Rest]) when Cmd == ?SB ->
    get_subcmd(Rest, []);

get_cmd([Cmd,Opt | Rest]) ->
    {[Cmd,Opt], Rest}.

get_subcmd([?SE | Rest], Acc) ->
    {[?SE | lists:reverse(Acc)], Rest};

get_subcmd([Opt | Rest], Acc) ->
    get_subcmd(Rest, [Opt | Acc]).

get_data(Cs) ->
    get_data1(Cs, []).

get_data1([], Acc) ->
    {lists:reverse(Acc), []};

get_data1([?IAC | Cs], Acc) ->
    {lists:reverse(Acc), [?IAC | Cs]};

get_data1([C | Cs], Acc) ->    
    get_data1(Cs, [C | Acc]).

printable([C | Cs]) when C == 10 ; C == 13 ->
    printable(Cs);

printable([C | Cs]) when C > 31 , C < 177 ->
    printable(Cs);

printable([C | Cs]) when C > 299 , C < 378 ->
    printable(Cs);

printable([]) ->
    true;

printable(_What) ->
    false.


dbg(Strs) ->
    case ?DBG of
	true ->
	    lists:foreach(fun(S) ->
				  case printable(S) of
				      true ->
					  io:format("~s", [S]);
				      false ->
					  io:format("~p", [S])
				  end
			  end, Strs),
	    io:nl();
	false ->
	    ok
    end.

